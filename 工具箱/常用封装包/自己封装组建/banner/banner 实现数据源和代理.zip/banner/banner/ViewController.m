//
//  ViewController.m
//  banner
//
//  Created by HUN on 16/6/8.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "ViewController.h"
#import "WHDbanner.h"


@interface ViewController ()<WHDbannerDatasource,WHDbannerDelegate>

@end

@implementation ViewController
{
    NSArray *arr;
    UIViewController *vc;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    CGFloat viewH=self.view.frame.size.height;
    CGFloat viewW=self.view.frame.size.width;
    arr=@[@"01",@"02",@"03",@"04",@"05"];
    self.automaticallyAdjustsScrollViewInsets=NO;
    WHDbanner *banner=[[WHDbanner alloc]initWithFrame:(CGRect){0,64,viewW,400}];
    banner.delegate=self;
    banner.datasource=self;
//    banner.models=@[@"01",@"02",@"03",@"04",@"05",@"06",@"07"];
    
    [self.view addSubview:banner];
    
//    UIImageView *vs=[[UIImageView alloc]initWithFrame:(CGRect){100,100,90,180}];
//    vs.image=[UIImage   imageNamed:@"01"];
//    [self.view addSubview:vs];
    
}

/**
 *  每个单元的
 */
-(UIButton *)WhdbannerItemAtIndexPath:(NSIndexPath *)indexPath
{
    UIButton *view=[[UIButton alloc]init];
    [view setImage:[UIImage imageNamed:arr[indexPath.row]] forState:UIControlStateNormal];
    return view;
}

/**
 *  行数,默认为1
 */
-(NSInteger)WhdbannerAtSection:(NSInteger )section
{
    return arr.count;
}

#pragma mark delegate
-(void)WhdbannerSeleted:(id)sender
{
    UIButton *send=sender;
    send.selected=!send.selected;
    vc=[[UIViewController alloc]init];
    vc.view.backgroundColor=[UIColor whiteColor];
    UIButton *btn=[[UIButton alloc]initWithFrame:(CGRect){vc.view.center.x-30,vc.view.center.y-30,60,60}];
    [btn addTarget:vc action:@selector(returnBack:) forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:[NSString stringWithFormat:@"%d",send.tag] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    vc.title=[NSString stringWithFormat:@"按钮的编号%d",send.tag];
    [vc.view addSubview:btn];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)returnBack:(UIButton*)sender
{
    NSLog(@"test。。。。。。");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
