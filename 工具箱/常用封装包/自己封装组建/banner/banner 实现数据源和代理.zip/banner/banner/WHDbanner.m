//
//  WHDbanner.m
//  banner
//
//  Created by HUN on 16/6/8.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "WHDbanner.h"

#define BANW self.frame.size.width
#define BANH self.frame.size.height
@interface WHDbanner ()<UIScrollViewDelegate>

@end
@implementation WHDbanner
{
    UIScrollView *scroll;
    UIPageControl *pageControl;
    NSTimer *time;
    UIButton *seletedBtn;
}


-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {

    }
    return self;
}
-(void)setModels:(NSArray *)models
{
    _models=models;
    //设置内容
    [self makeUpChild];
}

-(void)setDelegate:(id<WHDbannerDelegate>)delegate
{
    _delegate=delegate;
}
-(void)setDatasource:(id<WHDbannerDatasource>)datasource
{
    _datasource=datasource;
    [self makeUpChild];
}
#pragma mark 设置基础的子控件
-(void)makeUpChild
{
    NSIndexPath *indexpath;
    //设置页面高度
    CGFloat pageH=50;
    //设置scrollview
    scroll=[[UIScrollView alloc]initWithFrame:(CGRect){0,0,BANW,BANH-pageH}];
    scroll.backgroundColor=[UIColor yellowColor];
    scroll.pagingEnabled=YES;
    scroll.delegate=self;
    
    [self addSubview:scroll];
    //设置起始尺寸
    CGFloat btnW=scroll.frame.size.width;
    CGFloat btnH=scroll.frame.size.height;
    CGFloat oringalX=0;
    CGFloat oringalY=0;
    
    //设置总行列，主要是把内容给设置一下
    NSInteger section=[_datasource respondsToSelector:@selector(WhdbannerOfSection)]?[_datasource WhdbannerOfSection ]:1;
    CGFloat W=0;
    for (NSInteger i=0; i<section; i++) {
        //根据组数目，设置总列数
        NSInteger row=[_datasource respondsToSelector:@selector(WhdbannerAtSection:)]?[_datasource WhdbannerAtSection:i] : 0;
        if (!row) return;
        for (NSInteger j=0; j<row; j++) {
            indexpath=[NSIndexPath indexPathForRow:j inSection:i];
            UIButton *view=[_datasource WhdbannerItemAtIndexPath:indexpath];
            CGRect rectV=(CGRect){btnW*j,btnH*i,btnW,btnH};
            if ([_datasource respondsToSelector:@selector(WhdBannerViewAtIndexPath:)]) {
                rectV.size=[_datasource WhdBannerViewAtIndexPath:indexpath];
            }
            view.tag=j+10;
            [view addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            view.frame=rectV;
            W+=rectV.size.width;
            [scroll addSubview:view];
        }
        scroll.contentSize=(CGSize){W,BANH-pageH};
        
        //设置控制页面
        pageControl=[[UIPageControl alloc]initWithFrame:(CGRect){0,btnH,BANW,pageH}];
        //设置点的数目，还有选中颜色
        pageControl.numberOfPages=row;
        pageControl.currentPageIndicatorTintColor=[UIColor redColor];
        pageControl.pageIndicatorTintColor=[UIColor grayColor];
        if (pageControl.currentPage<=0) {
            pageControl.currentPage=0;
        }
        //添加点击事件
        [pageControl addTarget:self action:@selector(pageChange:) forControlEvents:UIControlEventValueChanged];
        [self addSubview:pageControl];
        
        //开始定时
//        [self beginTime];
        
    }
//    //设置起始尺寸
//    CGFloat btnW=scroll.frame.size.width;
//    CGFloat btnH=scroll.frame.size.height;
//    CGFloat oringalX=0;
//    CGFloat oringalY=0;
//    for (NSInteger i=0; i<self.models.count; i++)
//    {
//        UIButton *btn=[[UIButton alloc]initWithFrame:(CGRect){btnW*i,oringalY,btnW,btnH}];
//        [btn setImage:[UIImage imageNamed:self.models[i]] forState:UIControlStateNormal];
//        NSLog(@"%@",self.models[i]);
//        btn.tag=i+10;//设置标签
//        [scroll addSubview:btn];
//        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
//        
//        //另外的家手势的方法
//        UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(clipWay:)];
//        [btn addGestureRecognizer:pan];
//        
//    }
    

}

-(void)btnClick:(UIButton *)btn
{
    NSLog(@"%d",btn.tag);
    if ([self.delegate respondsToSelector:@selector(WhdbannerSeleted:)])
    {
        [self.delegate WhdbannerSeleted:btn];
    }
}

-(void)clipWay:(id)pan
{
    [self stopTime];
}

#pragma mark - time
/**
 *  定时方法
 */
-(void)timeShow:(NSTimer *)time
{
    CGPoint offset = scroll.contentOffset;
    offset.x += BANW;
    if (offset.x >= BANW*self.models.count) {
        offset.x=0;
    }
    [scroll setContentOffset:offset animated:YES];
    pageControl.currentPage = offset.x/BANW;
}

/**
 *  定时思考，要注意释放对象
 */
-(void)stopTime
{
    [time invalidate];
    time=nil;
}

/**
 *  开始定时器
 */
-(void)beginTime
{
    return;
    //设置定时器
    time=[NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timeShow:) userInfo:nil repeats:YES];
}
#pragma mark 定时用到了手势
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (time) {
        [self stopTime];
    }
}
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (time) {
        [self stopTime];
    }
}
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self beginTime];
}


#pragma mark - scrollDelegate
/**
 *  scrollView - delegate
 */
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSInteger index   =  (scrollView.contentOffset.x+BANW/2.0)/BANW;
    pageControl.currentPage=index;
}

#pragma mark - pageChange
/**
 *  pageChange的方法
 */
-(void)pageChange:(UIPageControl *)page
{
    //计算偏移值
    scroll.contentOffset=(CGPoint){BANW*page.currentPage,0};
}

@end
