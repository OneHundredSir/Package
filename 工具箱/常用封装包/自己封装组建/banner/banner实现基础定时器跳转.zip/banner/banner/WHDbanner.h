//
//  WHDbanner.h
//  banner
//
//  Created by HUN on 16/6/8.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol WHDbannerDelegate <NSObject>

-(void)WhdbannerSeleted:(id)sender;

@end

@protocol WHDbannerDatasource <NSObject>
/**
 *  每个单元的尺寸
 */
-(CGSize)WhdbannerItem;

/**
 *  行数,默认为1
 */
-(NSInteger)WhdbannerToSection;

/**
 *  列数
 */
@required
-(NSInteger)WhdbannerOfSection;

@end


@interface WHDbanner : UIView

@property(nonatomic,strong)NSArray *models;

@property(nonatomic,weak)id<WHDbannerDatasource> datasource;

@property(nonatomic,weak)id<WHDbannerDelegate> delegate;

@end
