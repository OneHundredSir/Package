//
//  ViewController.m
//  banner
//
//  Created by HUN on 16/6/8.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "ViewController.h"
#import "WHDbanner.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    CGFloat viewH=self.view.frame.size.height;
    CGFloat viewW=self.view.frame.size.width;
    WHDbanner *banner=[[WHDbanner alloc]initWithFrame:(CGRect){0,30,viewW,400}];
    banner.models=@[@"01",@"02",@"03",@"04",@"05",@"06",@"07"];
    [self.view addSubview:banner];
    
//    UIImageView *vs=[[UIImageView alloc]initWithFrame:(CGRect){100,100,90,180}];
//    vs.image=[UIImage   imageNamed:@"01"];
//    [self.view addSubview:vs];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
